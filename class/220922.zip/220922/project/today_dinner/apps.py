from django.apps import AppConfig


class TodayDinnerConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'today_dinner'
